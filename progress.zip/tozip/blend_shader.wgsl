#import bevy_pbr::{
    pbr_fragment::pbr_input_from_standard_material,
    //parallax_mapping::parallaxed_uv,
    pbr_functions::alpha_discard,
    pbr_functions::calculate_tbn_mikktspace,
    pbr_functions::apply_normal_mapping,
    pbr_bindings,
    pbr_types
    //pbr_parallax_mapping::parallaxed_uv
}

#ifdef PREPASS_PIPELINE
#import bevy_pbr::{
    prepass_io::{VertexOutput, FragmentOutput},
    pbr_deferred_functions::deferred_output,
}
#else
#import bevy_pbr::{
    forward_io::{VertexOutput, FragmentOutput},
    pbr_functions::{apply_pbr_lighting, main_pass_post_lighting_processing},
}
#endif

struct Splat{
    splat: f32,
    index1: u32,
    index2: u32
}

// the sample depth map and parallax uvs are not written by us but have been modified slightly to allow or blending
fn sample_depth_map(uv: vec2<f32>, splat: Splat) -> f32 {
    // We use `textureSampleLevel` over `textureSample` because the wgpu DX12
    // backend (Fxc) panics when using "gradient instructions" inside a loop.
    // It results in the whole loop being unrolled by the shader compiler,
    // which it can't do because the upper limit of the loop in steep parallax
    // mapping is a variable set by the user.
    // The "gradient instructions" comes from `textureSample` computing MIP level
    // based on UV derivative. With `textureSampleLevel`, we provide ourselves
    // the MIP level, so no gradient instructions are used, and we can use
    // sample_depth_map in our loop.
    // See https://stackoverflow.com/questions/56581141/direct3d11-gradient-instruction-used-in-a-loop-with-varying-iteration-forcing
    return mix(
        textureSampleLevel(parallax_array, parallax_sampler, uv, splat.index1, 0.0).r,
        textureSampleLevel(parallax_array, parallax_sampler, uv, splat.index2, 0.0).r,
        splat.splat
    );
}

// An implementation of parallax mapping, see https://en.wikipedia.org/wiki/Parallax_mapping
// Code derived from: https://web.archive.org/web/20150419215321/http://sunandblackcat.com/tipFullView.php?l=eng&topicid=28
fn parallaxed_uv(
    depth_scale: f32,
    max_layer_count: f32,
    max_steps: u32,
    // The original interpolated uv
    original_uv: vec2<f32>,
    // The vector from the camera to the fragment at the surface in tangent space
    Vt: vec3<f32>,
    splat: Splat
) -> vec2<f32> {
    if max_layer_count < 1.0 {
        return original_uv;
    }
    var uv = original_uv;

    // Steep Parallax Mapping
    // ======================
    // Split the depth map into `layer_count` layers.
    // When Vt hits the surface of the mesh (excluding depth displacement),
    // if the depth is not below or on surface including depth displacement (textureSample), then
    // look forward (+= delta_uv) on depth texture according to
    // Vt and distance between hit surface and depth map surface,
    // repeat until below the surface.
    //
    // Where `layer_count` is interpolated between `1.0` and
    // `max_layer_count` according to the steepness of Vt.

    let view_steepness = abs(Vt.z);
    // We mix with minimum value 1.0 because otherwise,
    // with 0.0, we get a division by zero in surfaces parallel to viewport,
    // resulting in a singularity.
    let layer_count = mix(max_layer_count, 1.0, view_steepness);
    let layer_depth = 1.0 / layer_count;
    var delta_uv = depth_scale * layer_depth * Vt.xy * vec2(1.0, -1.0) / view_steepness;

    var current_layer_depth = 0.0;
    var texture_depth = sample_depth_map(uv, splat);

    // texture_depth > current_layer_depth means the depth map depth is deeper
    // than the depth the ray would be at this UV offset so the ray has not
    // intersected the surface
    for (var i: i32 = 0; texture_depth > current_layer_depth && i <= i32(layer_count); i++) {
        current_layer_depth += layer_depth;
        uv += delta_uv;
        texture_depth = sample_depth_map(uv, splat);
    }

#ifdef RELIEF_MAPPING
    // Relief Mapping
    // ==============
    // "Refine" the rough result from Steep Parallax Mapping
    // with a **binary search** between the layer selected by steep parallax
    // and the next one to find a point closer to the depth map surface.
    // This reduces the jaggy step artifacts from steep parallax mapping.

    delta_uv *= 0.5;
    var delta_depth = 0.5 * layer_depth;

    uv -= delta_uv;
    current_layer_depth -= delta_depth;

    for (var i: u32 = 0u; i < max_steps; i++) {
        texture_depth = sample_depth_map(uv, splat);

        // Halve the deltas for the next step
        delta_uv *= 0.5;
        delta_depth *= 0.5;

        // Step based on whether the current depth is above or below the depth map
        if (texture_depth > current_layer_depth) {
            uv += delta_uv;
            current_layer_depth += delta_depth;
        } else {
            uv -= delta_uv;
            current_layer_depth -= delta_depth;
        }
    }
#else
    // Parallax Occlusion mapping
    // ==========================
    // "Refine" Steep Parallax Mapping by interpolating between the
    // previous layer's depth and the computed layer depth.
    // Only requires a single lookup, unlike Relief Mapping, but
    // may skip small details and result in writhing material artifacts.
    let previous_uv = uv - delta_uv;
    let next_depth = texture_depth - current_layer_depth;
    let previous_depth = sample_depth_map(previous_uv, splat) - current_layer_depth + layer_depth;

    let weight = next_depth / (next_depth - previous_depth);

    uv = mix(uv, previous_uv, weight);

    current_layer_depth += mix(next_depth, previous_depth, weight);
#endif

    // Note: `current_layer_depth` is not returned, but may be useful
    // for light computation later on in future improvements of the pbr shader.
    return uv;
}



// bindings so we can pass data from the cpu to the gpu, they start from 100 to not interfere with the standardmaterial bindings
@group(2) @binding(100)
var splatmap: texture_2d<f32>;
@group(2) @binding(101)
var splatmap_sampler: sampler;
@group(2) @binding(102)
var texture_array: texture_2d_array<f32>;
@group(2) @binding(103)
var array_sampler: sampler;

@group(2) @binding(104)
var normal_array: texture_2d_array<f32>;
@group(2) @binding(105)
var normal_sampler: sampler;

@group(2) @binding(106)
var parallax_array: texture_2d_array<f32>;
@group(2) @binding(107)
var parallax_sampler: sampler;

//@group(2) @binding(108)
//var<uniform> parallax_depths: array<f32>;


// a lot of this code is a modified version of bevy standardmaterial to take into account the blending, this code is currently quite a mess
@fragment
fn fragment(
    in: VertexOutput,
    @builtin(front_facing) is_front: bool,
) -> FragmentOutput {
    let double_sided = (pbr_bindings::material.flags & pbr_types::STANDARD_MATERIAL_FLAGS_DOUBLE_SIDED_BIT) != 0u;
    // TODO: mip_bias https://raw.githubusercontent.com/bevyengine/bevy/refs/tags/v0.15.3/crates/bevy_pbr/src/render/pbr_fragment.wgsl
    var pbr_input = pbr_input_from_standard_material(in, is_front);
    let psplato = textureSample(splatmap, splatmap_sampler, in.uv);

    let psplat = Splat(psplato.b, 0u, 1u);
    let uv_transform = pbr_bindings::material.uv_transform;
    var uv = (uv_transform * vec3(in.uv, 1.0)).xy;

    let V = pbr_input.V;
    let TBN = calculate_tbn_mikktspace(in.world_normal, in.world_tangent);
    let T = TBN[0];
    let B = TBN[1];
    let N = TBN[2];
    let Vt = vec3(dot(V, T), dot(V, B), dot(V, N));
    // TODO pass these as an array so they can change per texture
    let scaler = mix(
        0.4,
        -0.1,
        psplat.splat
    );
    let uvp_temp = parallaxed_uv(
        pbr_bindings::material.parallax_depth_scale * scaler,
        //(parallax.r) * 0.1,
        pbr_bindings::material.max_parallax_layer_count,
        pbr_bindings::material.max_relief_mapping_search_steps,
        uv,
        -Vt,
        psplat
    );
    //let uvp_temp = uv;
    let splat = textureSample(splatmap, splatmap_sampler, uv);
    let uvp = uvp_temp * 30.0 % 1;
    //let uvp = in.uv;
    let texture1 = u32(splat.r * 255.0 + 0.5);
    let texture2 = u32(splat.g * 255.0 + 0.5);
    let color = mix(
        textureSample(texture_array, array_sampler, uvp, texture1),
        textureSample(texture_array, array_sampler, uvp, texture2),
        splat.b
    );
    let normal = mix(
        textureSample(normal_array, normal_sampler, uvp, texture1),
        textureSample(normal_array, normal_sampler, uvp, texture2),
        splat.b
    ) * 2 - 1;
    
    // generate a PbrInput struct from the StandardMaterial bindings

    pbr_input.material.base_color = color;
    pbr_input.N = normalize(pbr_input.N);
    pbr_input.clearcoat_N = pbr_input.N;
    pbr_input.N = apply_normal_mapping(
        pbr_input.material.flags,
        TBN,
        double_sided,
        is_front,
        normal.xyz
    );

    pbr_input.material.base_color = alpha_discard(pbr_input.material, pbr_input.material.base_color);

#ifdef PREPASS_PIPELINE
    // in deferred mode we can't modify anything after that, as lighting is run in a separate fullscreen shader.
    let out = deferred_output(in, pbr_input);
#else
    var out: FragmentOutput;
    // apply lighting
    out.color = apply_pbr_lighting(pbr_input);

    // apply in-shader post processing (fog, alpha-premultiply, and also tonemapping, debanding if the camera is non-hdr)
    // note this does not include fullscreen postprocessing effects like bloom.
    out.color = main_pass_post_lighting_processing(pbr_input, out.color);

#endif
    return out;
}
