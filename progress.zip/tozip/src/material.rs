use bevy::{pbr::MaterialExtension, prelude::*, render::render_resource::{AsBindGroup, ShaderRef}};

/// A custom material that allows texture repeating and blending between multiple textures using a single mask/splatmap
/// 
/// the splatmap uses the r and g channels to define which texture/normal/depth to choose and the b channel to blend
#[derive(Asset, AsBindGroup, Clone, TypePath)]
pub struct TerrainMaterialExtension {
    #[texture(100)]
    #[sampler(101)]
    pub splatmap: Handle<Image>,

    #[texture(102, dimension = "2d_array")]
    #[sampler(103)]
    pub textures: Handle<Image>,

    #[texture(104, dimension = "2d_array")]
    #[sampler(105)]
    pub normals: Handle<Image>,

    #[texture(106, dimension = "2d_array")]
    #[sampler(107)]
    pub parallax: Handle<Image>
}
impl MaterialExtension for TerrainMaterialExtension {
    fn fragment_shader() -> ShaderRef {
        "blend_shader.wgsl".into()
    }
}